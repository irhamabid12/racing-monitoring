<?php

use App\Events\ListenDataEvent;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ListerningDataController;

Route::get('/', function () {
    return redirect()->route('dashboard');
});
Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/dashboard', [ListerningDataController::class, 'index'])->name('dashboard')->middleware('auth');